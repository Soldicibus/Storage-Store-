﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using Redisighn.Data;
using Redisighn.Models;

namespace Redisighn.Forms
{
    public partial class FormProductInfo : Form
    {
        public FormProductInfo()
        {
            InitializeComponent();     
            fillData();
            Dg.ReadOnly = true;
        }
        private void fillData()
        {
            RedisighnDbContext context = new RedisighnDbContext();
            var products = context.Products;

            Dg.ColumnCount = 3;
            Dg.Columns[0].Name = "Id";
            Dg.Columns[1].Name = "Name";
            Dg.Columns[2].Name = "Price";



            foreach (Product p in products)
            {
                ArrayList row = new ArrayList();
                row.Add(p.Id);
                row.Add(p.Name);
                row.Add(p.Price);
                Dg.Rows.Add(row.ToArray());
            }
        }
    }
}
