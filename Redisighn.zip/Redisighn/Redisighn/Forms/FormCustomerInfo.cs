﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using Redisighn.Data;
using Redisighn.Models;

namespace Redisighn.Forms
{
    public partial class FormCustomerInfo : Form
    {
        public FormCustomerInfo()
        {
            InitializeComponent();
            fillData();
            Dg.ReadOnly = true;
        } 
        private void fillData()
        {  
            RedisighnDbContext context = new RedisighnDbContext();
            var customers = context.Customers;
            
            Dg.ColumnCount = 6;
            Dg.Columns[0].Name = "Id";
            Dg.Columns[1].Name = "Name";
            Dg.Columns[2].Name = "Middle name";
            Dg.Columns[3].Name = "Surname";
            Dg.Columns[4].Name = "Phone";
            Dg.Columns[5].Name = "Adress";

           

            foreach (Customer c in customers)
            {
                ArrayList row = new ArrayList();
                row.Add(c.Id);
                row.Add(c.Name);
                row.Add(c.MiddleName);
                row.Add(c.Surname);
                row.Add(c.PhoneNumber);
                row.Add(c.Adress);
                Dg.Rows.Add(row.ToArray());
            }
        }
    }
}
