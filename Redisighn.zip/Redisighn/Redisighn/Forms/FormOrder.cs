﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Redisighn.Models;
using Redisighn.Data;
namespace Redisighn.Forms
{
    public partial class FormOrder : Form
    {
        RedisighnDbContext context = new RedisighnDbContext();
        public FormOrder()
        {
            InitializeComponent();
            fillData();
        }
        private void fillData()
        { 
            var customers = context.Customers;
            var products = context.Products;

            foreach (Customer c in customers) cbCustomer.Items.Add(c.Name + " " + c.MiddleName + " " + c.Surname);
            foreach (Product p in products) cbProduct.Items.Add(p.Name);
            
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnEnter_MouseHover(object sender, EventArgs e)
        {
            btnEnter.BackColor = Color.White;
            btnEnter.ForeColor = Color.FromArgb(33, 34, 74);
        }

        private void btnEnter_MouseLeave(object sender, EventArgs e)
        {
            btnEnter.ForeColor = Color.Gainsboro;
            btnEnter.BackColor = Color.FromArgb(33, 34, 74);
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            lblQuantity.Text = (int.Parse(lblQuantity.Text) + 1).ToString();
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            if(int.Parse(lblQuantity.Text) > 1)
            {
                lblQuantity.Text = (int.Parse(lblQuantity.Text) - 1).ToString();
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            bool checkProduct = true;
            bool checkCustomer = true;

            if(String.IsNullOrEmpty(cbCustomer.Text) || String.Equals(cbCustomer.Text, "Must be filled!"))
            {
                checkCustomer = false;
                cbCustomer.Text = "Must be filled!";
            }
            else
            {
                checkCustomer = true;
            }

            if(String.IsNullOrEmpty(cbProduct.Text) || String.Equals(cbProduct.Text, "Must be filled!"))
            {
                checkProduct = false;
                cbProduct.Text = "Must be filled";
            }
            else
            {
                checkProduct = true;
            }

            if(checkProduct && checkCustomer)
            {

                var customers = context.Customers;
                var products = context.Products;

                int cId = 0;
                int pId = 0;
                foreach(Customer c in customers)
                {
                    if(String.Equals(cbCustomer.Text, c.Name + " " + c.MiddleName + " " + c.Surname))
                    {
                        cId = c.Id;
                        break;
                    }
                }

                foreach (Product p in products)
                { 
                    if(String.Equals(cbProduct.Text, p.Name))
                    {
                        pId = p.Id;
                        break;
                    }
                }


                Order order = new Order
                {
                    CustomerId = cId,
                    ProductId = pId,
                    TimePlcaced = DateTime.Now,
                    TimeFulilled = DateTime.Now,
                    Quantity = int.Parse(lblQuantity.Text)
                };

                context.Orders.Add(order);
                context.SaveChanges();
                this.Close();
            }
        }
    }
}
