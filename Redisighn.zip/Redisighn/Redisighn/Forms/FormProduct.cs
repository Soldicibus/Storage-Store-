﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Redisighn.Models;
using Redisighn.Data;

namespace Redisighn.Forms
{
    public partial class FormProduct : Form
    {
        public FormProduct()
        {
            InitializeComponent();
        }

        private void btnEnter_MouseHover(object sender, EventArgs e)
        {
            btnEnter.BackColor = Color.White;
            btnEnter.ForeColor = Color.FromArgb(33, 34, 74);
        }

        private void btnEnter_MouseLeave(object sender, EventArgs e)
        {
            btnEnter.ForeColor = Color.Gainsboro;
            btnEnter.BackColor = Color.FromArgb(33, 34, 74);
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            bool checkName = true;
            bool checkPrice = true;

            if(String.IsNullOrEmpty(tbName.Text) || String.Equals(tbName.Text, "Wrong value!"))
            {
                checkName = false;
                tbName.Text = "Wrong value!";
            }
            else
            {
                checkName = true;
            }
            if(String.IsNullOrEmpty(tbPrice.Text) || (!tbPrice.Text.All(char.IsDigit) && !tbPrice.Text.Contains(',')))
            {
                checkPrice = false;
                tbPrice.Text = "Wrong value!";
            }
            else
            {
                checkPrice = true;
            }

            if(checkName && checkPrice)
            {
                RedisighnDbContext context = new RedisighnDbContext();

                Product product = new Product
                {
                    Name = tbName.Text,
                    Price = decimal.Parse(tbPrice.Text),
                };

                context.Products.Add(product);
                context.SaveChanges();
                this.Close();
            }
        }
    }
}
