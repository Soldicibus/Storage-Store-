﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Collections;
using Redisighn.Data;
using Redisighn.Models;

namespace Redisighn.Forms
{
    public partial class FormOrderInfo : Form
    {
        public FormOrderInfo()
        {
            InitializeComponent();
            fillData();
            Dg.ReadOnly = true;
        }
        private void fillData()
        {
            //Підключаємо сутності та Базу даних
            RedisighnDbContext context = new RedisighnDbContext();
            var orders = context.Orders;

            //Нумеруємо рядки та називаємо їх
            Dg.ColumnCount = 6;
            Dg.Columns[0].Name = "Id";
            Dg.Columns[1].Name = "Customer id";
            Dg.Columns[2].Name = "Product id";
            Dg.Columns[3].Name = "Time placed";
            Dg.Columns[4].Name = "Time fulfilled";
            Dg.Columns[5].Name = "Quantity";


            //Заровнюємо DataGird view
            foreach (Order o in orders)
            {
                ArrayList row = new ArrayList();
                row.Add(o.Id);
                row.Add(o.CustomerId);
                row.Add(o.ProductId);
                row.Add(o.TimePlcaced);
                row.Add(o.TimeFulilled);
                row.Add(o.Quantity);
                Dg.Rows.Add(row.ToArray());
            }
        }
    }
}
