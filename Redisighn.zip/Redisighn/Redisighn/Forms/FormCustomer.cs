﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Redisighn.Models;
using Redisighn.Data;
namespace Redisighn.Forms
{
    public partial class FormCustomer : Form
    {
        public FormCustomer()
        {
            InitializeComponent();
        }

        private void btnEnter_MouseHover(object sender, EventArgs e)
        {
            btnEnter.BackColor = Color.White;
            btnEnter.ForeColor = Color.FromArgb(33, 34, 74);
        }

        private void btnEnter_MouseLeave(object sender, EventArgs e)
        {
            btnEnter.ForeColor = Color.Gainsboro;
            btnEnter.BackColor = Color.FromArgb(33, 34, 74);
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            bool checkName = true;
            bool checkSurname = true;
            bool checkPhoneNumber = true;
            if(String.IsNullOrEmpty(tbName.Text) || String.Equals(tbName.Text, "Wrong value!"))
            {
                tbName.Text = "Wrong value!";
                checkName = false;
            }else
            {
                checkName = true;
            }

            if(String.IsNullOrEmpty(tbSurname.Text) || String.Equals(tbSurname.Text, "Wrong value!"))
            {
                tbSurname.Text = "Wrong value";
                checkSurname = false;
            }
            else
            {
                checkSurname = true;
            }

            if(!tbPhoneNumber.Text.All(char.IsDigit))
            {
                tbPhoneNumber.Text = "Wrong value";
                checkPhoneNumber = false;
            }
            else
            {
                checkPhoneNumber = true;
            }

            if(checkName && checkPhoneNumber && checkSurname)
            {
                RedisighnDbContext context = new RedisighnDbContext();

                Customer customer = new Customer()
                {
                    Name = tbName.Text,
                    Surname = tbSurname.Text,
                    MiddleName = tbMiddleName.Text,
                    PhoneNumber = tbPhoneNumber.Text,
                    Adress = tbAdress.Text,
                };

                context.Customers.Add(customer);
                context.SaveChanges();
                this.Close();
            }
        }
    }
}
