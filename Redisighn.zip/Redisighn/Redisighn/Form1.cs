using FontAwesome.Sharp;
using System.Runtime.InteropServices;
using Redisighn.Forms;
namespace Redisighn
{
    public partial class Form1 : Form
    {

        private IconButton currentButton;
        private Panel leftBorderBtn;
        private Form currentChildForm;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            leftBorderBtn = new Panel();
            leftBorderBtn.Size = new Size(7, 60);
            panelMenu.Controls.Add(leftBorderBtn);
            //Form

            this.ControlBox = false;
            this.DoubleBuffered = true;
            this.Text = String.Empty;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;

        }
        //Structs
        private struct RGBColours
        {
            public static Color color1 = Color.FromArgb(172, 126, 241);
            public static Color color2 = Color.FromArgb(249, 118, 176);
            public static Color color3 = Color.FromArgb(253, 138, 114);
            public static Color color4 = Color.FromArgb(95, 77, 221);
            public static Color color5 = Color.FromArgb(249, 88, 155);
            public static Color color6 = Color.FromArgb(24, 161, 251);
        }

        private void ActivateButton(object senderButton, Color color)
        {
           if(senderButton != null)
            {
                DisableButton();
                //Button
                currentButton = (IconButton)senderButton;
                currentButton.BackColor = Color.FromArgb(37, 36, 81);
                currentButton.ForeColor = color;
                currentButton.TextAlign = ContentAlignment.MiddleCenter;
                currentButton.IconColor = color;
                currentButton.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentButton.ImageAlign = ContentAlignment.MiddleRight;
                //Left border button
                leftBorderBtn.BackColor = color;
                leftBorderBtn.Location = new Point(0, currentButton.Location.Y);
                leftBorderBtn.Visible = true;
                leftBorderBtn.BringToFront();
                //Icon current child form
                iconCurrentChildForm.IconChar = currentButton.IconChar;
                iconCurrentChildForm.IconColor = color;
            }
        }

        private void openChildForm(Form childForm)
        {
            if(currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            childForm.ForeColor = currentButton.ForeColor;
            panelDesktop.Controls.Add(childForm);
            panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitleChildForm.Text = childForm.Text;
        }
        private void DisableButton()
        {
            if(currentButton != null)
            {
                currentButton.BackColor = Color.FromArgb(31, 30, 68);
                currentButton.ForeColor = Color.Gainsboro;
                currentButton.TextAlign = ContentAlignment.MiddleCenter;
                currentButton.IconColor = Color.Gainsboro;
                currentButton.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentButton.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }

        //Add new order
        private void btnOrder_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColours.color1);
            openChildForm(new FormOrder());
        }

        //Product information
        private void btnProductInfo_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColours.color2);
            openChildForm(new FormProductInfo());

        }

        //Order information
        private void btnOrderInfo_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColours.color3);
            openChildForm(new FormOrderInfo());
        }

        //Add new customer
        private void btnCustomer_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColours.color4);
            openChildForm(new FormCustomer());
        }

        //Add new product
        private void btnProduct_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColours.color5);
            openChildForm(new FormProduct());
        }

        //Customer information
        private void btnCustomerInfo_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, RGBColours.color6);
            openChildForm(new FormCustomerInfo());
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Reset()
        {
            DisableButton();
            iconCurrentChildForm.IconChar = IconChar.HouseChimney;
            iconCurrentChildForm.IconColor = Color.MediumPurple;
            panelDesktop.Controls.Clear();
            currentChildForm = null;
            leftBorderBtn.Visible = false;
            lblTitleChildForm.Text = "Home";
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panelTitileBar_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {
            if(WindowState == FormWindowState.Normal)
                WindowState = FormWindowState.Maximized;
            else
                WindowState = FormWindowState.Normal;
        }

        private void iconPictureBox3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void iconPictureBox1_MouseHover(object sender, EventArgs e)
        {
            iconPictureBox1.IconColor = Color.LightCoral;
        }
        private void iconPictureBox1_MouseLeave(object sender, EventArgs e)
        {
            iconPictureBox1.IconColor = Color.SlateBlue;
        }        
        private void iconPictureBox2_MouseHover(object sender, EventArgs e)
        {
            iconPictureBox2.IconColor = Color.PaleTurquoise;
        }
        private void iconPictureBox2_MouseLeave(object sender, EventArgs e)
        {
            iconPictureBox2.IconColor = Color.SlateBlue;
        }

        private void iconPictureBox3_MouseHover(object sender, EventArgs e)
        {
            iconPictureBox3.IconColor = Color.Moccasin;
        }

        private void iconPictureBox3_MouseLeave(object sender, EventArgs e)
        {
            iconPictureBox3.IconColor = Color.SlateBlue;
        }
    }
}